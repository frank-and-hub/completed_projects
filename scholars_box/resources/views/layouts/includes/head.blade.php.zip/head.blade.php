<head>
    <!-- //components/app/master.blade.php    -->
    <!-- Basic Page Needs -->
    <meta charset="utf-8">

    <!-- Metas -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta name="author" content="ED">
    <meta name="asd" content="{{ csrf_token() }}">

    <title>CSR</title>
    <meta name="description" content="">
    <meta name="keywords" content="" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="" />
    <meta property="og:url" content="" />
    <meta property="og:title" content="CSR" />
    <meta property="og:description" content="" />
    <meta property="og:image" content="" />
    <meta name="twitter:card" content="photo" />
    <meta property="twitter:url" content="" />
    <meta name="twitter:title" content="CSR" />
    <meta name="twitter:image" content="" />
    <meta property="twitter:description" content="" />
    <meta name="csrf-token" content="{{ csrf_token() }}">


</head>
